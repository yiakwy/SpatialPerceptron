from __future__ import absolute_import
from modelarts.client.api_client import ApiClient
import re
import six

class InfersImageApi(object):

    def __init__(self, api_client=None):
        if api_client is None:
            api_client = ApiClient()
        self.api_client = api_client

    def service_model_reasoning_files(self, list, type, **kwargs):
        kwargs['_return_http_data_only'] = True
        return self.service_model_reasoning_with_http_info_files(list,  type, **kwargs)

    def service_model_reasoning_with_http_info_files(self, list,  type, **kwargs):
        all_params = ['list']
        all_params.append('async')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')
        #Get all variables in the method
        params = locals()
        #Traverse key-value pairs to see if they are in all_params
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method service_model_reasoning" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter type is set
        if ('list' not in params or
                    params['list'] is None):
            raise ValueError("Missing the required parameter type when calling `service_model_reasoning`")
        #Assignment to the corresponding parameter
        collection_formats = {}

        path_params = {}

        query_params = []

        header_params = {}

        form_params = []

        local_var_files = {}
        #Assignment type
        if 'list' in params:
            local_var_files[type] = params['list']

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])

        # HTTP header `Content-Type`
        header_params['Content-Type'] = self.api_client.select_header_content_type(
            ['multipart/form-data'])

        # Authentication setting
        auth_settings = ['ApiTokenAuth']

        return self.api_client.call_api(
            '/', 'POST',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='InfersResponse',
            auth_settings=auth_settings,
            async=params.get('async'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)