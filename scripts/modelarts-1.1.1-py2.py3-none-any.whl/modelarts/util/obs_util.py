from obs import ObsClient, DeleteObjectsRequest, Object
from ..exception.obs_exception import OBSException,OBSUploadException,OBSDownloadException
import logging as logger
import os

LOGGER = logger.getLogger('obs')

class OBS():
    """
        OBS SDK Operation using temporary AK/SK
    """
    def __init__( self, server=None, ak=None, sk=None, security_token=None, is_secure=True, path_style=True):
        """AK SK and security_token comes from IAM's temporary AK/SK API
        """
        if ak is None or sk is None or server is None:
            raise Exception("Parameter is illegal!")

        self.server = server
        self.ak = ak
        self.sk = sk
        if security_token and security_token.strip() != "":
            self.security_token = security_token
        else:
            self.security_token = None

        self.is_secure = is_secure
        self.path_style = path_style
        self.obs_client = ObsClient(access_key_id=self.ak,
                              secret_access_key=self.sk,
                              security_token=self.security_token,
                              is_secure=self.is_secure,
                              server=self.server,
                              path_style=self.path_style)

    def check_bucket_path(self, bucket_path):
        if bucket_path.startswith('/'):
            bucket_path = bucket_path[1:]
        if bucket_path.endswith('/'):
            bucket_path = bucket_path[:-1]
        return bucket_path

    def list_buckets(self):
        try:
            resp = self.obs_client.listBuckets()
            if resp.status > 300:
                raise OBSException(code=resp.errorCode, message=resp.errorMessage)
            else:
                bucket_list = []
                buckets = resp.body.buckets
                for bucket in buckets:
                    bucket_list.append(bucket['name'])
                return bucket_list
        except OBSException:
            raise OBSException(code=resp.errorCode, message=resp.errorMessage)
        except Exception as e:
            raise Exception("Create OBS bucket failed! ", e)

    def create_bucket(self, bucket_name, location):
        try:
            bucket_list = self.list_buckets()
            if bucket_name in bucket_list:
                print("%s is existed" % (bucket_name))
                return bucket_name
            else:
                resp = self.obs_client.createBucket(bucketName=bucket_name, location=location)
                if resp.status > 300:
                    raise OBSException(code=resp.errorCode, message=resp.errorMessage)
                else:
                    print("Successfully create bucket %s " %(bucket_name))
                    return bucket_name
        except OBSException:
            raise OBSException(code=resp.errorCode, message=resp.errorMessage)
        except Exception as e:
            raise Exception("Create OBS bucket failed! ", e)

    def delete_bucket(self, bucket_name):
        try:
            resp = self.obs_client.deleteBucket(bucketName=bucket_name)
            if resp.status > 300:
                raise OBSException(code= resp.errorCode, message=resp.errorMessage)
            else:
                print("Successfully delete bucket %s " % (bucket_name))
                return resp
        except OBSException:
            raise OBSException(code=resp.errorCode, message=resp.errorMessage)
        except Exception as e:
            raise Exception("Delete OBS bucket failed! ", e)

    def list_top_num_objects(self, bucket_name, num):
        """You can get obejects using following example:
               for content in resp.body.contents:
                   print('\t' + content.key + ' etag[' + content.etag + ']')
        """
        try:
            resp = self.obs_client.listObjects(bucket_name, max_keys=num)
            if resp.status > 300:
                raise OBSException(code=resp.errorCode, message=resp.errorMessage)
            else:
                print("Successfully list bucket %s object" % (bucket_name))
                return resp
        except OBSException:
            raise OBSException(code=resp.errorCode, message=resp.errorMessage)
        except Exception as e:
            raise Exception("List OBS objects failed! ", e)

    def put_object( self, bucket_path, local_file_path):
        """put local file to OBS
           if the bucket_name does not exist in OBS, then it will throw 404 exception
           if the bucket path does not exist in the bucket Name, then it will be created
           if OBS has existed the file in the specified path, then it will be overwritten
        """
        try:
            if not os.path.exists(local_file_path):
                raise Exception("File " + local_file_path + " does not exist!")
            file_name = os.path.split(local_file_path)[-1]
            resp = self.obs_client.putFile( bucket_path, file_name, local_file_path)
            if resp.status > 300:
                raise OBSUploadException(code=resp.errorCode, message=resp.errorMessage)
            else:
                print("Successfully upload file %s to OBS %s" % (local_file_path, bucket_path))
                LOGGER.info("Successfully upload file %s to OBS %s" % (local_file_path, bucket_path))
        except OBSUploadException:
            raise OBSException(code=resp.errorCode, message=resp.errorMessage)
        except Exception as e:
            raise Exception("Upload file to OBS failed! ", e)

    def put_directory(self, bucket_path, local_directory):
        """put multi local files to OBS
           if the bucket_name does not exist in OBS, then it will throw 404 exception
           if the bucket path does not exist in the bucket Name, then it will be created
           if OBS has existed the file in the specified path, then it will be overwritten
        """
        try:
            local_directory = local_directory.rstrip('/')
            if not os.path.exists(local_directory):
                raise Exception("Directory " + local_directory + " does not exist!")
            file_name = os.path.split(local_directory)[-1]
            resp = self.obs_client.putFile(bucket_path, file_name, local_directory)
            for file in resp:
                if os.path.isdir(os.path.split(local_directory)[0] + '/' +file[0]):
                    self.put_directory(bucket_path + '/' + file[0][:file[0].rfind('/')], os.path.split(local_directory)[0] + '/' +file[0])
                else:
                    if file[1].status > 300:
                        raise OBSUploadException(code=file[1].status, message=file[1].reason)
                    else:
                        print("Successfully upload file %s to OBS %s" % (local_directory, bucket_path))
                        LOGGER.info("Successfully upload file %s to OBS %s" % (local_directory, bucket_path))
        except OBSUploadException:
            raise OBSUploadException(code=file[1].status, message=file[1].reason)
        except Exception as e:
            raise Exception("Upload file to OBS failed! ", e)

    def put_multi_objects(self, bucket_path, local_file_paths):
        """put local directory to OBS, splitted using ','
           if the bucket_name does not exist in OBS, then it will throw 404 exception
           if the bucket path does not exist in the bucket Name, then it will be created
           if OBS has existed the file in the specified path, then it will be overwritten
        """
        for local_file_path in local_file_paths:
            try:
                if not os.path.exists(local_file_path):
                    raise Exception("File " + local_file_path + " does not exist!")
                if os.path.isdir(local_file_path):
                    self.put_directory(bucket_path, local_file_path)
                else:
                    self.put_object(bucket_path, local_file_path)
            except Exception as e:
                raise Exception("Upload multi files to OBS failed! ", e)

    def download_object(self, bucket_path, local_file_path):
        """download OBS file to your local file
           if local path has existed the file, then it will be overwritten
        """
        try:
            bucket_path_split = bucket_path.split('/',1)
            bucket_name = bucket_path_split[0]
            object_name = bucket_path_split[1]
            resp = self.obs_client.getObject(bucket_name, object_name, downloadPath=local_file_path)
            if resp.status > 300:
                raise OBSDownloadException(code=resp.errorCode, message=resp.errorMessage)
            else:
                print("Successfully download file %s from OBS to local %s" % (bucket_path, local_file_path))
                LOGGER.info("Successfully download file %s from OBS to local %s" % (bucket_path, local_file_path))
        except OBSDownloadException:
            raise OBSDownloadException(code=resp.errorCode, message=resp.errorMessage)
        except Exception as e:
            raise Exception("Download file from OBS failed! ", e)

    def download_directory(self, bucket_path, local_storage_path):
        """download OBS directory to your local path
           if local path has existed the file, then it will be overwritten
        """
        try:
            bucket_path = bucket_path.rstrip('/')
            local_storage_path = local_storage_path.rstrip('/')
            local_storage_path = local_storage_path + '/' + bucket_path.split('/')[-1]
            bucket_path_split = bucket_path.split('/', 1)
            bucket_name = bucket_path_split[0]
            object_name = bucket_path_split[1] + "/"
            resp = self.obs_client.listObjects(bucket_name, object_name)
            if resp.status > 300:
                    raise OBSDownloadException(code=resp.errorCode, message=resp.errorMessage)

            base_dir = local_storage_path
            for content in resp.body.contents:
                if content.key[-1] != '/':
                    bucket_path = bucket_name + "/" + content.key
                    if '/' in content.key.split(object_name)[-1]:
                        local_storage_dir = base_dir + '/' + content.key.split(object_name)[-1].rsplit('/', 1)[0]
                    else:
                        local_storage_dir = base_dir
                    if not os.path.exists(local_storage_dir):
                        os.makedirs(local_storage_dir)
                    local_file_path = local_storage_dir.rstrip('/') + '/' + content.key.rsplit('/', 1)[-1]
                    self.download_object(bucket_path, local_file_path)
                else:
                    local_storage_dir = base_dir + '/' + content.key.split(object_name)[-1]
                    if not os.path.exists(local_storage_dir):
                        os.makedirs(local_storage_dir.rstrip('/'))
        except OBSDownloadException:
            raise OBSDownloadException(code=resp.errorCode, message=resp.errorMessage)
        except Exception as e:
            raise Exception("Download directory from OBS failed! ", e)

    def get_object_size(self, bucket_name, object_name):
        try:
            resp = self.obs_client.getObjectMetadata(bucket_name, object_name)
            if resp.status > 300:
                raise OBSException(code=resp.errorCode, message=resp.errorMessage)
            header = dict(resp.header)
            object_size = int(header.get('content-length'))
            return object_size
        except OBSException:
            raise OBSException(code=resp.errorCode, message=resp.errorMessage)
        except Exception as e:
            raise Exception("Get object size from OBS failed! ", e)

    def delete_objects(self,bucket):
        """ Delete all objects in bucket
        return: Whether the deletion is successful
        """
        object_list = self.list_all_objects(bucket)
        for objects in object_list:
            delete_objects_resp = self.obs_client.deleteObject(bucket, objects)
            if delete_objects_resp.status > 300:
                print(delete_objects_resp.errorMessage)
                raise Exception("Delete files existed in bucket failed.")
        return True

    def create_directory(self,bucket,directory):
        """
        Create a directory in bucket.
        """
        if directory[-1] != "/":
            directory = directory + "/"

        if directory[0]  == "/":
            directory = directory[1:]

        create_dir_resp = self.obs_client.putContent(bucket, directory,content = None)
        if create_dir_resp.status < 300:
            print("Create directory %s successfully" % directory)
        else:
            print('errorMessage: ', create_dir_resp.errorMessage)
            raise Exception("Create directory failed.")


    def list_all_objects(self,bucket):
         """
         list all objects in bucket
         return: objects list[key, versionId]
         """
         objects_list = []
         marker = None
         while True:
             list_objects_resp = self.obs_client.listObjects(bucket, max_keys=100, marker=marker)
             if list_objects_resp.status < 300:
                 for content in list_objects_resp.body.contents:
                     objects_list.append(content.key)

                 if not list_objects_resp.body.is_truncated:
                     break
                 marker =  list_objects_resp.body.next_marker
             else:
                 raise Exception("Get bucket objects list failed.")

         return objects_list