from ..auth.api.auth_api import AuthApi
import sys, os, datetime, hashlib, hmac
import requests
import json
import logging
from ..util import apig_signer
from ..exception.apig_exception import APIGException
from ..exception.iam_exception import IAMException

logging.basicConfig()
LOGGER = logging.getLogger('modelarts-sdk')

def authorize(username, password, domain, region, api_client=None):
    """
    Set auth information to client configure
    :param username:  User name
    :param password:  User password
    :param domain:  Account name
    :return:
    """
    if username is None or password is None:
        raise IllegalArgumentError("username and password can not be None")

    if domain is None and username is not None:
        domain = username
    auth = {
        "auth": {
            "identity": {
                "methods": [
                    "password"
                ],
                "password": {
                    "user": {
                        "name": username,
                        "password": password,
                        "domain": {
                            "name": domain
                        }
                    }
                }
            },
            "scope": {
                "project": {
                    "domain": {
                        "name": domain
                    },
                    "name": region
                }
            }
        }
    }
    authapi = AuthApi(api_client)
    return_data, response_status, response_headers = authapi.authorize_with_http_info(auth)
    return response_headers['X-Subject-Token'], return_data


def get_temporary_aksk_without_commission(token, iam_url):
    """get IAM's temporary AK/SK without commission which lasts for 24h
       :return: {
                "credential": {
                    "access": "0HCKAXX*********QUP9GE",
                    "expires_at": "2019-08-03T01:22:55.858000Z",
                    "securitytoken": "gQtjbi1nbG9******iYW"
                    "secret": "2Cr05fTRfmeG*****nXpa538s0ny6Laqv"
                    }
                }
    """
    body = {
        "auth": {
            "identity": {
                "methods": [
                    "token"
                ],
                "token": {
                    "duration-seconds": "86400"
                }
            }
        }
    }
    headers = {
        "X-Auth-Token": token,
        "Content-Type": "application/json"
    }
    url = "https://" + iam_url + "/v3.0/OS-CREDENTIAL/securitytokens"
    try:
        response = requests.post(url, headers=headers, data=json.dumps(body), verify=False)
        if response.status_code > 300:
            resp = response.json()['error']
            message = "[ {} ] {}".format(resp['code'], resp['message'])
            raise IAMException(code=response.status_code, message=message)
        else:
            return response
    except IAMException:
        raise IAMException(code=response.status_code, message=message)
    except Exception as e:
        raise Exception(e)

def sign(key, msg):
    return hmac.new(key, msg.encode("utf-8"), hashlib.sha256).digest()

def get_signature_key(key, date_stamp, region_name, service_name):
    kDate = sign(('HWS' + key).encode('utf-8'), date_stamp)
    kRegion = sign(kDate, region_name)
    kService = sign(kRegion, service_name)
    kSigning = sign(kService, 'hws_request')
    return kSigning

def authorize_by_token(username, password, account, region, endpoint):
    """
    Set auth information to client configure
    :param username:  User name
    :param password:  User password
    :param account:  Account name
    :return:
    """
    if username is None or password is None:
        raise IllegalArgumentError("username and password can not be None")

    if account is None and username is not None:
        account = username

    body = {
        "auth": {
            "identity": {
                "methods": [
                    "password"
                ],
                "password": {
                    "user": {
                        "name": username,
                        "password": password,
                        "domain": {
                            "name": account
                        }
                    }
                }
            },
            "scope": {
                "project": {
                    "domain": {
                        "name": account
                    },
                    "name": region
                }
            }
        }
    }
    headers = {
        "Content-Type": "application/json"
    }
    url = "https://" + endpoint + "/v3/auth/tokens"
    try:
        response = requests.post(url, headers=headers, data=json.dumps(body), verify=False)
        if response.status_code > 300:
            resp = response.json()['error']
            message = "[ {} ] {}".format(resp['code'], resp['message'])
            raise IAMException(code=response.status_code, message=message)
        else:
            token = response.headers['X-Subject-Token']
            project_id = response.json()['token']['project']['id']
            return token, project_id
    except IAMException:
        raise IAMException(code=response.status_code, message=message)
    except Exception as e:
        raise Exception(e)

def authorize_by_aksk(access_key, secret_key, region, iam_url):

    method = 'POST'
    service = 'iam'
    host = iam_url
    region = region
    endpoint = 'https://' + iam_url + '/v3/auth/tokens'
    access_key = access_key
    secret_key = secret_key

    content_type = 'application/json;charset=utf8'
    request_parameters = '{"auth": {"identity": {"methods": ["hw_access_key"],"hw_access_key": {"access": {"key": "' + access_key + '"}}},"scope": {"project": {"name": "' + region + '"}}}}'
    t = datetime.datetime.utcnow()
    hws_date = t.strftime('%Y%m%dT%H%M%SZ')
    date_stamp = t.strftime('%Y%m%d')

    canonical_uri = '/v3/auth/tokens/'
    canonical_querystring = ''
    canonical_headers = 'content-type:' + content_type + '\n' + 'host:' + host + '\n' + 'x-hws-date:' + hws_date + '\n'
    signed_headers = 'content-type;host;x-hws-date'
    payload_hash = hashlib.sha256(request_parameters.encode('utf-8')).hexdigest()
    canonical_request = method + '\n' + canonical_uri + '\n' + canonical_querystring + '\n' + canonical_headers + '\n' + signed_headers + '\n' + payload_hash
    algorithm = 'HWS-HMAC-SHA256'
    credential_scope = date_stamp + '/' + region + '/' + service + '/' + 'hws_request'
    string_to_sign = algorithm + '\n' + hws_date + '\n' + credential_scope + '\n' + hashlib.sha256(
        canonical_request.encode('utf-8')).hexdigest()
    signing_key = get_signature_key(secret_key, date_stamp, region, service)
    signature = hmac.new(signing_key, (string_to_sign).encode('utf-8'), hashlib.sha256).hexdigest()

    authorization_header = algorithm + ' ' + 'Credential=' + access_key + '/' + credential_scope + ', ' + 'SignedHeaders=' + signed_headers + ', ' + 'Signature=' + signature

    headers = {'Content-Type': content_type,
               'X-Hws-Date': hws_date,
               'X-Identity-Sign': authorization_header}

    sslverification = False
    res = requests.post(endpoint, data=request_parameters, headers=headers, verify=sslverification)

    if res.status_code == 201:
        project_id = res.json()['token']['project']['id']
        token = res.headers['X-Subject-Token']
    else:
        raise Exception("Get IAM token using ak/sk failed")

    return token, project_id

def auth_by_APIG(access_key, secret_key, method, host, request_url, query=None, body=None, headers=None):
    sig = apig_signer.Signer()
    sig.AppKey = access_key
    sig.AppSecret = secret_key

    r = apig_signer.HttpRequest()
    r.scheme = "https"
    r.host = host
    r.method = method
    r.uri = request_url
    if query:
        r.query = query
    else:
        r.query = {}
    if headers:
        r.headers = headers
    else:
        r.headers = {"Content-Type": "application/json"}
    if body:
        r.body = body
        sig.Sign(r)
        resp = requests.request(r.method, r.scheme + "://" + r.host + r.uri, headers=r.headers, data=r.body)
    else:
        sig.Sign(r)
        resp = requests.request(r.method, r.scheme + "://" + r.host + r.uri, headers=r.headers)
    if resp.status_code > 300:
        print(resp.content)
        raise APIGException(code=resp.status_code, message=resp.reason)
    return json.loads(resp.content)

class IllegalArgumentError(ValueError):
    pass