
class ConfigException(RuntimeError):
    pass