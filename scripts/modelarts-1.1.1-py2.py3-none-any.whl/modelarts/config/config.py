from .config_exception import ConfigException
import json
import os
from ..client.configuration import Configuration
from ..client.api_client import ApiClient

from .auth import *
from ..auth.configuration import Configuration as AuthConfiguration
from ..auth.api_client import ApiClient as AuthApiClient

MODELARTS_CONFIG = os.getenv("MODELARTS_CONFIG", "~/.modelarts/config.json")


class ModelArtsConfigLoader(object):
    def __init__(self, config_context, active_context=None,
                 hc_credentials=None,
                 config_base_path=""):
        self._config = ConfigSite('modelarts', config_context)
        self._current_context = None
        self._user = None
        self._cluster = None
        self.set_active_context(active_context)
        self._config_base_path = config_base_path
        self._hc_credentials = hc_credentials

    def set_active_context(self, context_name=None):
        if context_name is None:
            context_name = self._config['current-context']
        self._current_context = self._config['contexts'].get_with_name(
            context_name)
        if (self._current_context['context'].safe_get('user') and
                self._config.safe_get('users')):
            user = self._config['users'].get_with_name(
                self._current_context['context']['user'], safe=True)
            if user:
                self._user = user['user']
            else:
                self._user = None
        else:
            self._user = None
        self._cluster = self._config['clusters'].get_with_name(
            self._current_context['context']['cluster'])['cluster']

    def load_and_set(self, client_configuration, access_key=None, secret_key=None, username=None, password=None, account=None):
        self._load_cluster_info()
        self._set_config(client_configuration)
        if access_key and secret_key:
            self._load_authentication(client_configuration, access_key=access_key , secret_key=secret_key)
        elif username and password:
            self._load_authentication(client_configuration, username=username, password=password, account=account)
        else:
            self._load_authentication(client_configuration)

    def _load_authentication(self, client_configuration, access_key=None, secret_key=None, username=None, password=None, account=None):
        if access_key and secret_key:
            return
        if username and password :
            self.auth_using_account(client_configuration, username, password, account)
            return
        if not self._user:
            return
        if self._load_hec_token(client_configuration):
            return

    def _load_hec_token(self, client_configuration):
        if self._hc_credentials:
            self.token = self._hc_credentials
            return True
        else:
            self._refresh_hc_credentials(client_configuration)

        if 'token' in self.__dict__:
            client_configuration.api_key['X-Auth-Token'] = self.token
            return True

        return False

    def _refresh_hc_credentials(self, client_configuration):
        auth_configuration = AuthConfiguration()
        region = getattr(client_configuration, "region")
        auth_configuration.host = "https://iam.{}.myhuaweicloud.com".format(self.region)


        keys = ['verify_ssl', 'proxy', 'ssl_ca_cert', 'cert_file', 'key_file']
        for key in keys:
            if key in client_configuration.__dict__:
                setattr(auth_configuration, key, getattr(client_configuration, key))

        if 'username' in self._user and 'password' in self._user:
            username = self._user['username']
            password = self._user['password']
            account = None
            try:
                account = self._user['account']
            except:
                pass
            if (account is not None) and (account.strip(' \t\n\r') != ""):
                domain = account
            else:
                domain = self._user['username']

        token, _ = authorize(domain=domain, username=username, password=password, region=region,
                             api_client=AuthApiClient(auth_configuration))
        self.token = token
        os.environ["PROJECT_ID"] = _.token.project.id

    def auth_using_account(self, client_configuration, username, password, account=None):
        auth_configuration = AuthConfiguration()
        region = getattr(client_configuration, "region")
        endpoint = "iam.{}.myhuaweicloud.com".format(self.region)

        keys = ['verify_ssl', 'proxy', 'ssl_ca_cert', 'cert_file', 'key_file']
        for key in keys:
            if key in client_configuration.__dict__:
                setattr(auth_configuration, key, getattr(client_configuration, key))

        if (account is not None) and (account.strip(' \t\n\r') != ""):
            domain = account
        else:
            domain = username

        token, project_id = authorize_by_token(username=username, password=password, account=domain, region=region, endpoint=endpoint)

        self.token = token
        os.environ["PROJECT_ID"] = project_id
        client_configuration.api_key['X-Auth-Token'] = token

    def _load_cluster_info(self):
        self.verify_ssl = False

        if 'region' in self._cluster:
            self.region = self._cluster['region']
            self.host = "https://modelarts.{}.myhuaweicloud.com".format(self.region)



        if 'proxy' in self._cluster:
            self.proxy = self._cluster['proxy']
        if 'verify_ssl' in self._cluster:
            self.verify_ssl = _str2bool(self._cluster['verify_ssl'])

    def _set_config(self, client_configuration):
        keys = ['region', 'host', 'verify_ssl', 'proxy', 'ssl_ca_cert', 'cert_file', 'key_file']
        for key in keys:
            if key in self.__dict__:
                setattr(client_configuration, key, getattr(self, key))

    def list_contexts(self):
        return [context.value for context in self._config['contexts']]

    @property
    def current_context(self):
        return self._current_context.value


class ConfigSite(object):

    def __init__(self, name, value):
        self.name = name
        self.value = value

    def __contains__(self, key):
        return key in self.value

    def __len__(self):
        return len(self.value)

    def safe_get(self, key):
        if (isinstance(self.value, list) and isinstance(key, int) or
                key in self.value):
            return self.value[key]

    def __getitem__(self, key):
        v = self.safe_get(key)
        if not v:
            raise ConfigException(
                'Invalid ModelArts config file. Expected key %s in %s'
                % (key, self.name))
        if isinstance(v, dict) or isinstance(v, list):
            return ConfigSite('%s/%s' % (self.name, key), v)
        else:
            return v

    def get_with_name(self, name, safe=False):
        if not isinstance(self.value, list):
            raise ConfigException(
                'Invalid ModelArts config file. Expected %s to be a list'
                % self.name)
        result = None
        for v in self.value:
            if 'name' not in v:
                raise ConfigException(
                    'Invalid ModelArts config file. '
                    'Expected all values in %s list to have \'name\' key'
                    % self.name)
            if v['name'] == name:
                if result is None:
                    result = v
                else:
                    raise ConfigException(
                        'Invalid ModelArts config file. '
                        'Expected only one object with name %s in %s list'
                        % (name, self.name))
        if result is not None:
            return ConfigSite('%s[name=%s]' % (self.name, name), result)
        if safe:
            return None
        raise ConfigException(
            'Invalid ModelArts config file. '
            'Expected object with name %s in %s list' % (name, self.name))


def _str2bool(v):
    return v.lower() in ("yes", "true", "t", "1", "True")


def _get_config_loader(filename, **kwargs):
    with open(filename) as f:
        config_json = json.load(f)
        config_path = os.path.abspath(os.path.dirname(filename))
        return ModelArtsConfigLoader(config_context=config_json, config_base_path=config_path, **kwargs)


def _load_config(config_file=None, context=None, client_configuration=None, credential=None, access_key=None, secret_key=None, username=None, password=None, account=None):
    if config_file is None:
        config_file = os.path.expanduser(MODELARTS_CONFIG)

    loader = _get_config_loader(
        config_file, active_context=context, hc_credentials=credential)
    if client_configuration is None:
        config = type.__call__(Configuration)
        loader.load_and_set(config, access_key=access_key, secret_key=secret_key, username=username, password=password, account=account)
        Configuration.set_default(config)
    else:
        loader.load_and_set(client_configuration, access_key=access_key, secret_key=secret_key, username=username, password=password, account=account)


def list_config_contexts(config_file=None):
    if config_file is None:
        config_file = os.path.expanduser(MODELARTS_CONFIG)

    loader = _get_config_loader(config_file)
    return loader.list_contexts(), loader.current_context

def create_client(
        config_file=None, context=None, credential=None, access_key=None, secret_key=None, username=None, password=None, account=None):
    """
    create apiclient by context config
    :param config_file: config file
    :param context: context name
    :param credential: user token
    :return:

    Examples:
       from modelarts import config
       client = config.create_client(context="normal_user")
    """
    client_config = type.__call__(Configuration)
    _load_config(config_file=config_file, context=context,
                 client_configuration=client_config, credential=credential,
                 access_key=access_key, secret_key=secret_key, username=username, password=password, account=account)
    api_client = ApiClient(configuration=client_config)
    #Dynamic add context property
    ApiClient.context = None
    api_client.context = context
    return api_client

def refresh_token(api_client, config_file=None, context=None, credential=None, access_key=None, secret_key=None, username=None, password=None, account=None):
    """

    :param api_client:
    :param config_file:
    :param context:
    :param credential:
    :return:

    Examples:
       from modelarts import config
       client = config.create_client(context="normal_user")
       config.refresh_token(client)
    """
    client_config = api_client.configuration
    if context is None:
        context = api_client.context
    _load_config(config_file=config_file, context=context,
                 client_configuration=client_config, credential=credential,
                 access_key=access_key, secret_key=secret_key, username=username, password=password, account=account)