import time, sys
from datetime import datetime, timedelta
from .client.api import *
from .predictor import *
from .config.auth import auth_by_APIG
from json import JSONEncoder

ISO_TIME_FORMAT = '%m%d-%H%M%S'
CREATE_MODEL_PARAMS = set(['model_name', 'model_version', 'source_location',
                           'source_job_id', 'source_job_version', 'source_type',
                           'model_type', 'model_algorithm', 'description', 'execution_code',
                           'input_params', 'output_params', 'dependencies', 'model_metrics', 'apis'])
DEPLOY_SERVICE_PARAMS = set(['service_name', 'description', 'infer_type', 'vpc_id',
                             'subnet_network_id', 'security_group_id', 'configs'])
MODEL_WAIT_SECOND = 5
MAXIMUM_RETRY_TIMES = 200


class Model(object):
    """
    A ModelArts Model that can be created model, deployed model service,
    got model info and list, and deleted model and service endpoint.
    """

    def __init__(self, session):
        """
        Initialize a model, determine the model authorize type.
        param session: Building interactions with HUAWEI Cloud service.
        """
        self.session = session
        self.service_id = None
        self.model_id = None
        if self.session.auth == 'aksk':
            self.model_instance = ModelApiAKSKImpl(self.session)
        else:
            self.model_instance = ModelApiAccountImpl(self.session)

    def create_model(self, **kwargs):
        """ creating model interface
        Args:
            kwargs: Create model body params
        Returns:
            dict: model_id that creating successfully
        """
        self.model_instance.check_params(**kwargs)
        model_create_resp = self.model_instance.create_modelarts_model()
        self.model_id = self.model_instance.model_id
        return model_create_resp

    def deploy_predictor(self, **kwargs):
        """ Deploying model predictor interface
            Args:
                kwargs: Deploying predictor body params
            Returns:
                dict: service_id that creating successfully
        """
        self.model_instance.check_params(**kwargs)
        model_deploy_resp = self.model_instance.deploy_modelarts_predictor()
        self.service_id = self.model_instance.service_id
        return model_deploy_resp

    def deploy_transformer(self, **kwargs):
        """  Deploying model transformer interface
             Args:
                kwargs: Deploying predictor body params
             returns:
                dict: service_id that creating successfully
        """
        return self.deploy_predictor(**kwargs)

    def get_model_list(self):
        """
        return user's current models
        """
        return self.model_instance.get_model_list()

    def get_model_info_list(self, model_id=None):
        """
        return model information list of the input model_id or the last created model
        """
        return self.model_instance.get_model_info_list(model_id=model_id)

    def delete_model_endpoint(self, model_id=None, service_id=None):

        self.model_instance.delete_model_endpoint(model_id=model_id, service_id=service_id)

    def delete_model(self, model_id=None):

        self.model_instance.delete_model(model_id=model_id)

    def delete_service(self, service_id=None):

        self.model_instance.delete_service(service_id=service_id)

    def get_service_id(self):

        return self.service_id

    def get_model_id(self):

        return self.model_id


class ModelApiBase(with_metaclass(ABCMeta, object)):
    """ A ModelArts Model that can be created model, deployed model service and delete model endpoint. """

    def __init__(self):

        """
        Initialize a ModelArts Model instance.
        """

    def check_params(self, **kwargs):
        """ Checking the model parameters validity from console
         Args:
             kwargs(dict): creating model parameters or deploying service parameters
        """
        if 'configs' in kwargs:
            config_set = set(kwargs.keys()) - DEPLOY_SERVICE_PARAMS
            if len(config_set) == 0:
                self._generate_service_params(service_params=kwargs)
            else:
                raise ValueError('The input params: %s for deploying service is surplus' % config_set)

        else:
            config_set = set(kwargs.keys()) - CREATE_MODEL_PARAMS
            if len(config_set) == 0:
                self._generate_model_params(model_params=kwargs)
            else:
                raise ValueError('The input params: %s for creating model is surplus' % config_set)

    def _generate_model_params(self, model_params):
        """ Processing and generating the model create parameters:
            [model_name, model_version, source_location, model_type, execution_code]

            Args:
                model_params: the model parameters
        """
        self.create_model_body = model_params

        def _splice_obs_url(params):
            if params[0] == '/':
                params = params[1:]
            return "https://" + params.split("/", 1)[0] + ".obs.myhwclouds.com/" + params.split("/", 1)[1]

        if 'model_name' not in model_params:
            beijing_date = (datetime.now() + timedelta(hours=8)).strftime(ISO_TIME_FORMAT)
            self.create_model_body['model_name'] = 'model-' + beijing_date
        print("Model name is %s " % self.create_model_body['model_name'])

        if 'model_version' not in model_params:
            self.create_model_body['model_version'] = '0.0.1'

        if 'source_location' in model_params:
            self.create_model_body['source_location'] = _splice_obs_url(model_params['source_location'])
            if self.create_model_body['source_location'][-1] == "/":
                self.create_model_body['source_location'] = self.create_model_body['source_location'][:-1]
            print("The model source location is " + self.create_model_body['source_location'])
        else:
            raise ValueError('The model source_location is required')

        if 'model_type' not in model_params:
            raise ValueError('The model_type is required')

        if 'execution_code' in model_params:
            self.create_model_body['execution_code'] = _splice_obs_url(model_params['execution_code'])

        if 'input_params' in model_params:
            self.create_model_body['input_params'] = self._convert_params_format(model_params['input_params'])

        if 'output_params' in model_params:
            self.create_model_body['output_params'] = self._convert_params_format(model_params['output_params'])

    def _convert_params_format(self, params):

        params_format = []
        for put_param in params:
            one_param = {}
            one_param['url'] = put_param.url
            one_param['param_name'] = put_param.param_name
            one_param['param_type'] = put_param.param_type

            if put_param.min is not None:
                one_param['min'] = put_param.min

            if put_param.max is not None:
                one_param['max'] = put_param.max

            if put_param.param_desc is not None:
                one_param['param_desc'] = put_param.param_desc

            params_format.append(one_param)

        return params_format

    @abstractmethod
    def create_modelarts_model(self):
        """ Creating model
            Args:
                session: Building interactions with HUAWEI Cloud service.
            Returns:
                The model id that created successfully, will be used in deploying service.
        """
        pass

    def _generate_service_params(self, service_params):

        """ Processing and generating the model service parameters:
            [service_name, infer_type, vpc_id, config(dict)]
            Args:
                service_params: The model service parameters
        """

        def _splice_obs_url(params):
            """ convert custom path to obs path format
            :return: obs format path
            """
            if len(params) == 0:
                raise ValueError('The current obs path is null. ')
            if params[0] == '/':
                params = params[1:]
            return "https://" + params.split("/", 1)[0] + ".obs.myhwclouds.com/" + params.split("/", 1)[1]

        self.deploy_service_body = service_params

        if 'service_name' not in service_params:
            beijing_date = (datetime.now() + timedelta(hours=8)).strftime(ISO_TIME_FORMAT)
            self.deploy_service_body['service_name'] = 'service-' + beijing_date
        print("Service name is %s" % self.deploy_service_body['service_name'])

        if 'infer_type' not in service_params:
            self.deploy_service_body['infer_type'] = 'real-time'

        if 'vpc_id' in service_params and (
                'subnet_network_id' not in service_params or 'security_group_id' not in service_params):
            raise ValueError('subnet_network_id and security_group_id are required when using vpc_id')

        if 'configs' in service_params:
            config_value = []
            if hasattr(service_params['configs'][0], 'req_uri'):  # batch config
                for service_config in service_params['configs']:
                    one_config = {}
                    one_config['model_id'] = service_config.model_id
                    one_config['specification'] = service_config.specification
                    one_config['instance_count'] = service_config.instance_count
                    one_config['src_path'] = _splice_obs_url(service_config.src_path)
                    one_config['dest_path'] = _splice_obs_url(service_config.dest_path)
                    one_config['req_uri'] = service_config.req_uri
                    one_config['mapping_type'] = service_config.mapping_type

                    if service_config.mapping_rule is not None:
                        one_config['mapping_rule'] = service_config.mapping_rule
                    if service_config.envs is not None:
                        one_config['envs'] = service_config.envs
                    config_value.append(one_config)

            elif hasattr(service_params['configs'][0], 'weight'):  # real-time config
                for service_config in service_params['configs']:
                    one_config = {}
                    one_config['model_id'] = service_config.model_id
                    one_config['specification'] = service_config.specification
                    one_config['instance_count'] = service_config.instance_count
                    one_config['weight'] = service_config.weight

                    if service_config.envs is not None:
                        one_config['envs'] = service_config.envs
                    config_value.append(one_config)
            else:
                raise ValueError("The input configs are wrong.")

            self.deploy_service_body['configs'] = config_value
            self.deploy_service_body['config'] = self.deploy_service_body.pop("configs")

        else:
            raise ValueError('The configs are required.')

    @abstractmethod
    def deploy_modelarts_predictor(self):
        """ Deploying model predictor
            Args:
                session: Build interactions with HUAWEI Cloud Service.
            Returns:
                Predictor.
        """
        pass

    @abstractmethod
    def delete_model_endpoint(self):
        """ Deleting model endpoint, including model and service.
            It will print the deleting result.
            Args:
                 session: Building interactions with HUAWEI Cloud Service.
                 model(dict): including model id
                 servide(dict): including service id
        """
        pass

    def is_reach_maximum_times(self, max_attempt_times):
        if max_attempt_times > MAXIMUM_RETRY_TIMES:
            return True
        else:
            return False

    @abstractmethod
    def get_model_list(self):
        """
        return User model list
        """
        pass

    @abstractmethod
    def get_model_info_list(self):
        """
        :return model information.
        """
        pass

    @abstractmethod
    def _get_service_list(self):
        """
        return User service list
        """
        pass

    @abstractmethod
    def _get_service_info(self):
        """
        return: the service information
        """
        pass

    @abstractmethod
    def delete_model(self):
        """
        return: delete model endpoint
        """
        pass

    @abstractmethod
    def delete_service(self):
        """
        return: delete service endpoint
        """
        pass


class ModelApiAccountImpl(ModelApiBase):
    """ A ModelArts Model that can be created model, deployed model service and delete model endpoint. """

    def __init__(self, session):

        """
        Initialize a ModelArts Model instance.
        """
        self.session = session
        self.model_api = ModelApi(self.session.client)
        self.service_api = ServiceApi(self.session.client)

    def create_modelarts_model(self):
        """ Creating model
            Args:
                session: Building interactions with HUAWEI Cloud service.
            Returns:
                The model id that created successfully, will be used in deploying service.
        """
        model_create_resp = self.model_api.create_the_model(project_id=self.session.project_id,
                                                            body=self.create_model_body)
        self.model_id = model_create_resp.model_id

        count_status_query_times = 0
        print_status_flag = True
        while True:
            model_query_resp = self.get_model_info_list()

            count_status_query_times += 1
            if super(ModelApiAccountImpl, self).is_reach_maximum_times(count_status_query_times):
                print(
                    "Reach the maximum model status query times, the current status is %s" % service_query_resp.status)
                break

            if model_query_resp.model_status == 'published':
                print(model_query_resp.model_status)
                break
            else:
                if print_status_flag:
                    print_status_flag = False
                    print(model_query_resp.model_status)
                time.sleep(MODEL_WAIT_SECOND)

        return model_create_resp

    def deploy_modelarts_predictor(self):
        """ Deploying model service
            Args:
                session: Build interactions with HUAWEI Cloud Service.
            Returns:
                Predictor.
        """
        service_deploy_resp = self.service_api.create_service(project_id=self.session.project_id,
                                                              body=self.deploy_service_body)
        self.service_id = service_deploy_resp.service_id
        previous_deploy_progress = 0
        count_status_query_times = 0
        while True:
            service_query_resp = self._get_service_info()
            count_status_query_times += 1
            if super(ModelApiAccountImpl, self).is_reach_maximum_times(count_status_query_times):
                print(
                    "Reach the maximum service status query times, the current status is %s" % service_query_resp.status)
                break

            if service_query_resp.status == 'running':
                previous_deploy_progress = 100
                sys.stdout.write('\rDeploy progress: %s%%' % previous_deploy_progress)
                sys.stdout.flush()
                print("\nDeploy finished")
                break
            elif service_query_resp.status == 'deploying' or service_query_resp.status == 'finished':
                if service_query_resp.progress > previous_deploy_progress:
                    previous_deploy_progress = service_query_resp.progress
                    sys.stdout.write('\rDeploy progress: %s%%' % previous_deploy_progress)
                time.sleep(MODEL_WAIT_SECOND)
            else:
                raise Exception("Abnormal service id %s ,the status is %s " %
                                (self.service_id, service_query_resp.status))

        return PredictorApiAccountImpl(self.session, self.service_id)

    def delete_model_endpoint(self, model_id=None, service_id=None):
        """ Deleting model endpoint, including model and service.
            It will print the deleting result.
            Args:
                 session: Building interactions with HUAWEI Cloud Service.
                 model(dict): including model id
                 servide(dict): including service id
        """
        if service_id is not None:
            self.delete_service(service_id=service_id)
            count_service_retry_times = 0
            while True:
                count_service_retry_times += 1
                if super(ModelApiAccountImpl, self).is_reach_maximum_times(count_service_retry_times):
                    print("Can't get the service %s delete information." % service_id)
                    break

                services_list = self._get_service_list()
                if service_id in [tmp.service_id for tmp in services_list.services]:
                    time.sleep(MODEL_WAIT_SECOND)
                else:
                    print('Delete the service %s endpoint successfully.' % service_id)
                    break

        if model_id is not None:
            self.delete_model(model_id=model_id)
            count_model_retry_times = 0
            while True:
                count_model_retry_times += 1
                if super(ModelApiAccountImpl, self).is_reach_maximum_times(count_model_retry_times):
                    print("Can't get the model %s delete information." % model_id)
                    break

                model_list = self.get_model_list()
                if model_id in [tmp.model_id for tmp in model_list.models]:
                    time.sleep(MODEL_WAIT_SECOND)
                else:
                    print('Delete the model %s endpoint successfully.' % model_id)
                    break

    def delete_model(self, model_id=None):
        """ Only delete model endpoint
        """
        if model_id is None:
            model_id = self.model_id

        self.model_api.delete_a_model(project_id=self.session.project_id, model_id=model_id)

    def delete_service(self, service_id=None):
        """ Only delete model endpoint
        """
        if service_id is None:
            service_id = self.service_id

        self.service_api.delete_micro_service(project_id=self.session.project_id, service_id=service_id)

    def get_model_list(self):
        """
        return User model list
        """
        return self.model_api.get_model_list(project_id=self.session.project_id)

    def get_model_info_list(self, model_id=None):
        """
        :return model information.
        """
        if model_id is None:
            model_id = self.model_id

        return self.model_api.get_model_info_list(project_id=self.session.project_id, model_id=model_id)

    def _get_service_list(self):
        """
        return User service list
        """
        return self.service_api.get_service_list(project_id=self.session.project_id)

    def _get_service_info(self):
        """
        return: the service information
        """
        return self.service_api.get_service_info(project_id=self.session.project_id, service_id=self.service_id)


class ModelApiAKSKImpl(ModelApiBase):
    """ A ModelArts Model that can be created model, deployed model service and delete model endpoint. """

    def __init__(self, session):

        """
        Initialize a ModelArts Model instance.
        """
        self.session = session

    def create_modelarts_model(self):
        """ Creating model
            Args:
                session: Building interactions with HUAWEI Cloud service.
            Returns:
                The model id that created successfully, will be used in deploying service.
        """
        request_url = '/v1/' + self.session.project_id + '/models'
        create_model_body = JSONEncoder().encode(self.create_model_body)

        model_create_resp = auth_by_APIG(self.session.access_key, self.session.secret_key, 'POST', self.session.host,
                                         request_url, '', create_model_body)
        self.model_id = model_create_resp['model_id']
        count_status_query_times = 0
        print_status_flag = True

        while True:
            model_query_resp = self.get_model_info_list()
            count_status_query_times += 1
            if super(ModelApiAKSKImpl, self).is_reach_maximum_times(count_status_query_times):
                print(
                    "Reach the maximum status query times, the current status is %s" % model_query_resp['model_status'])
                break

            if model_query_resp['model_status'] == 'published':
                print(model_query_resp['model_status'])
                break

            else:
                if print_status_flag:
                    print_status_flag = False
                    print(model_query_resp['model_status'])
                time.sleep(MODEL_WAIT_SECOND)

        return model_query_resp

    def deploy_modelarts_predictor(self):
        """ Deploying model predictor
            Args:
                session: Build interactions with HUAWEI Cloud Service.
            Returns:
                Predictor.
        """

        request_url = '/v1/' + self.session.project_id + '/services'
        create_service_body = JSONEncoder().encode(self.deploy_service_body)
        service_deploy_resp = auth_by_APIG(self.session.access_key, self.session.secret_key, 'POST', self.session.host,
                                           request_url, '', create_service_body)
        self.service_id = service_deploy_resp['service_id']
        previous_deploy_progress = 0
        count_status_query_times = 0
        while True:
            service_query_resp = self._get_service_info()
            count_status_query_times += 1

            if super(ModelApiAKSKImpl, self).is_reach_maximum_times(count_status_query_times):
                print("Reach the maximum service status query times, the status is %s" % service_query_resp['status'])
                break

            if service_query_resp['status'] == 'running':
                previous_deploy_progress = 100
                sys.stdout.write('\rDeploy progress: %s%%' % previous_deploy_progress)
                sys.stdout.flush()
                print("\nDeploy finished")
                break

            elif service_query_resp['status'] == 'deploying' or service_query_resp['status'] == 'finished':
                if service_query_resp['progress'] > previous_deploy_progress:
                    previous_deploy_progress = service_query_resp['progress']
                    sys.stdout.write('\rDeploy progress: %s%%' % previous_deploy_progress)
                time.sleep(MODEL_WAIT_SECOND)

            else:
                raise Exception("Abnormal service id %s ,the status is %s " %
                                (self.service_id, service_query_resp['status']))

        return PredictorApiAKSKImpl(self.session, self.service_id)

    def delete_model_endpoint(self, model_id=None, service_id=None):
        """ Deleting model endpoint, including model and service.
            It will print the deleting result.
            Args:
                 session: Building interactions with HUAWEI Cloud Service.
                 model(dict): including model id
                 servide(dict): including service id
        """
        if service_id is not None:
            self.delete_service(service_id=service_id)
            count_service_retry_times = 0
            while True:
                count_service_retry_times += 1
                if super(ModelApiAKSKImpl, self).is_reach_maximum_times(count_service_retry_times):
                    print("Can't get the service %s delete information." % service_id)
                    break

                services_list = self._get_service_list()
                services = services_list['services']
                if service_id in [tmp['service_id'] for tmp in services]:
                    time.sleep(MODEL_WAIT_SECOND)
                else:
                    print('Delete the service %s endpoint successfully.' % service_id)
                    break

        if model_id is not None:
            self.delete_model(model_id=model_id)
            count_model_retry_times = 0
            while True:
                count_model_retry_times += 1
                if super(ModelApiAKSKImpl, self).is_reach_maximum_times(count_model_retry_times):
                    print("Can't get the model %s delete information." % model_id)
                    break

                model_list = self.get_model_list()

                if model_id in [tmp['model_id'] for tmp in model_list['models']]:
                    time.sleep(MODEL_WAIT_SECOND)
                else:
                    print('Delete the model %s endpoint successfully.' % model_id)
                    break

    def get_model_list(self):
        """
        return User model list
        """
        request_url = '/v1/' + self.session.project_id + '/models'
        return auth_by_APIG(self.session.access_key, self.session.secret_key, 'GET', self.session.host, request_url, '')

    def get_model_info_list(self, model_id=None):
        """
        :return model information.
        """
        request_url = '/v1/' + self.session.project_id + '/models/'
        if model_id is None:
            model_id = self.model_id

        request_url = request_url + model_id
        return auth_by_APIG(self.session.access_key, self.session.secret_key, 'GET', self.session.host, request_url, '')

    def _get_service_list(self):
        """
        return User service list
        """
        request_url = '/v1/' + self.session.project_id + '/services'
        return auth_by_APIG(self.session.access_key, self.session.secret_key, 'GET', self.session.host, request_url, '')

    def _get_service_info(self):
        """
        return: the service information
        """
        request_url = '/v1/' + self.session.project_id + '/services/' + self.service_id
        return auth_by_APIG(self.session.access_key, self.session.secret_key, 'GET', self.session.host, request_url, '')

    def delete_service(self, service_id=None):
        """Delete a service
        """
        if service_id is None:
            service_id = self.service_id

        request_url = '/v1/' + self.session.project_id + '/services/' + service_id
        auth_by_APIG(self.session.access_key, self.session.secret_key, 'DELETE', self.session.host, request_url, '')

    def delete_model(self, model_id=None):
        """Delete a model
        """
        if model_id is None:
            model_id = self.model_id

        request_url = '/v1/' + self.session.project_id + '/models/' + model_id
        auth_by_APIG(self.session.access_key, self.session.secret_key, 'DELETE', self.session.host, request_url, '')
