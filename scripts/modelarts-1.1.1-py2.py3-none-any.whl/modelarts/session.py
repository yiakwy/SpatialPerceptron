import os
import logging
import json
import hashlib
import shutil
from .config import config
from .util.obs_util import OBS

logging.basicConfig()
LOGGER = logging.getLogger('modelarts-sdk')
LOGGER.setLevel(logging.INFO)
MODELARTS_CONFIG = os.getenv("MODELARTS_CONFIG", "~/.modelarts/config.json")

class Session(object):
    """Manage interactions with the HUAWEIYUN services needed.

    This class provides convenient methods for manipulating other services,
    such as iam auth, operation in OBS.

    """
    def __init__(self, config_file=None, username=None, password=None, access_key=None, secret_key=None, region_name=None, account=None, project_id=None):
        """Initialize a SageMaker ``Session``.

        Args:
            access_key : obs ak.
            secret_key : obs sk.
            region_name : region such as southchina.

        """
        self.local_mode = False
        if config_file:
            self.config_file = config_file
        elif os.path.exists(os.path.expanduser(MODELARTS_CONFIG)):
            self.config_file = os.path.expanduser(MODELARTS_CONFIG)
        else:
            config_dir = os.path.expanduser("~/.modelarts")
            if not os.path.exists(config_dir):
                os.makedirs(config_dir)
            shutil.copyfile(os.path.dirname(config.__file__) + '/config.json', os.path.expanduser(MODELARTS_CONFIG))
            self.config_file = os.path.expanduser(MODELARTS_CONFIG)

        if region_name:
            self.region_name = region_name
        elif "REGION_NAME" in os.environ:
            self.region_name = os.environ["REGION_NAME"]
        else:
            with open(self.config_file) as f:
                config_json = json.load(f)
                self.region_name = config_json['clusters'][0]['cluster']['region']

        self.host = "modelarts.{}.myhuaweicloud.com".format(self.region_name)

        if self.region_name == 'southchina':
            obs_server = '100.125.70.22'
            iam_server = "iam.myhuaweicloud.com:31943"
        elif self.region_name == 'cn-north-1':
            obs_server = "obs.{}.myhuaweicloud.com".format(self.region_name)
            iam_server = "iam.{}.myhuaweicloud.com".format(self.region_name)
        elif self.region_name == 'cn-north-7':
            obs_server = "obs.{}.ulanqab.huawei.com".format(self.region_name)
            iam_server = "iam-cache-proxy.myhuaweicloud.com:31943"
        elif self.region_name == 'ap-southeast-1':
            obs_server = "obs.{}.myhwclouds.com".format(self.region_name)
            iam_server = "iam-cache-proxy.ap-southeast-1.hwclouds.com:31943"
        else:
            raise ValueError('Unrecognized region name of {}'.format(region_name))

        if username and password:
            self.account = account
            self.username = username
            self.password = password
        else:
            with open(self.config_file) as f:
                config_json = json.load(f)
                user_info = config_json['users'][0]['user']
                if 'account' in user_info:
                    self.account = user_info['account']
                else:
                    self.account = None
                self.username = user_info['username']
                self.password = user_info['password']

        if (access_key and secret_key) or ("ACCESS_KEY_ID" in os.environ and 'SECRET_ACCESS_KEY' in os.environ):
            if access_key and secret_key:
                self.access_key = access_key
                self.secret_key = secret_key
            else:
                self.access_key = os.environ["ACCESS_KEY_ID"]
                self.secret_key = os.environ["SECRET_ACCESS_KEY"]
            self.auth = 'aksk'
            self.obs_client = OBS(server=obs_server, ak=self.access_key, sk=self.secret_key)
            self.client = config.create_client(context="default", access_key=self.access_key, secret_key=self.secret_key)
        else:
            self.auth = 'account'
            token, project_id = config.authorize_by_token(username=self.username,
                                                          password=self.password,
                                                          account=self.account,
                                                          region=self.region_name,
                                                          endpoint=iam_server)
            res = config.get_temporary_aksk_without_commission(token, iam_server)
            self.access_key = res.json()['credential']['access']
            self.secret_key = res.json()['credential']['secret']
            security_token = res.json()['credential']['securitytoken']
            self.obs_client = OBS(server=obs_server, ak=self.access_key, sk=self.secret_key,
                                  security_token=security_token)
            if username and password:
                self.client = config.create_client(context="default", username=self.username, password=self.password, account=self.account)
            else:
                self.client = config.create_client(context="default")

        if project_id:
            self.project_id = project_id
        elif "PROJECT_ID" in os.environ:
            self.project_id = os.environ["PROJECT_ID"]
        else:
            raise Exception('project_id is required for init session')

    def create_bucket(self, bucket):
        """Create OBS bucket to use in relevant ModelArts interactions.
        Returns:
            str: bucket
        """
        return self.obs_client.create_bucket(bucket_name=bucket, location=self.region_name)

    def default_bucket(self, bucket = None):
        """Return the name of the default OBS bucket to use in relevant ModelArts interactions.

        Returns:
            str: The name of the default bucket, which is of the form: ``auto-job-{timestamp}``.
        """
        if bucket:
            return self.obs_client.create_bucket(bucket_name=bucket, location=self.region_name)
        else:
            project_id_md5 = hashlib.md5(self.project_id.encode('utf-8')).hexdigest()[:8]
            default_bucket = 'modelarts-{}-{}'.format(self.region_name, project_id_md5)
            return self.obs_client.create_bucket(bucket_name=default_bucket, location=self.region_name)

    def upload_data(self, bucket_path, path):
        """Upload local file or directory to obs.
        """
        bucket_path = self.obs_client.check_bucket_path(bucket_path)
        if isinstance(path, list):
            self.obs_client.put_multi_objects(bucket_path=bucket_path, local_file_paths=path)
        elif isinstance(path, str):
            if not os.path.exists(path):
                raise Exception("Path " + path + " does not exist!")
            if os.path.isdir(path):
                self.obs_client.put_directory(bucket_path=bucket_path, local_directory=path)
            elif os.path.isfile(path):
                self.obs_client.put_object(bucket_path=bucket_path, local_file_path=path)
        else:
            raise Exception('local path should be list or string')

    def download_data(self, bucket_path, path):
        if not os.path.exists(path) and not os.path.exists(os.path.abspath(os.path.dirname(path))):
            raise Exception("Path " + path + " does not exist!")
        is_directory = bucket_path.endswith('/')
        bucket_path = self.obs_client.check_bucket_path(bucket_path)
        if is_directory:
            obs_objects = self.obs_client.list_all_objects(bucket_path.split('/', 1)[0])
            object_name = bucket_path.split('/', 1)[1] + '/'
            is_exist = any(obj.startswith(object_name) for obj in obs_objects)
            if not is_exist:
                raise Exception("OBS bucket path does not exist, please check it! ")
            self.obs_client.download_directory(bucket_path=bucket_path, local_storage_path=path)
        else:
            self.obs_client.download_object(bucket_path=bucket_path, local_file_path=path)

    def delete_bucket(self, bucket):
        if self.obs_client.delete_objects(bucket):
            self.obs_client.delete_bucket(bucket)

    def create_directory(self,bucket,directory):
        self.obs_client.create_directory(bucket, directory)
