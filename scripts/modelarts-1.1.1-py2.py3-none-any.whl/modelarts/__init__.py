



__project__="modelarts"
# The version is auto-updated. Please do not edit.
__version__="1.0.0"

import modelarts.config
import modelarts.client



