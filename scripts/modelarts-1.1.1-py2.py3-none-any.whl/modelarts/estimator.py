from .client.api import *
from .model import *
from datetime import datetime, timedelta

JOB_STATE = ['JOBSTAT_UNKNOWN', 'JOBSTAT_INIT', 'JOBSTAT_IMAGE_CREATING', 'JOBSTAT_IMAGE_FAILED',
             'JOBSTAT_SUBMIT_TRYING',
             'JOBSTAT_SUBMIT_FAILED', 'JOBSTAT_DELETE_FAILED', 'JOBSTAT_WAITING', 'JOBSTAT_RUNNING', 'JOBSTAT_KILLING',
             'JOBSTAT_COMPLETED', 'JOBSTAT_FAILED', 'JOBSTAT_KILLED', 'JOBSTAT_CANCELED', 'JOBSTAT_LOST',
             'JOBSTAT_SCALING']
HTTPS_GET = 'GET'
HTTPS_POST = 'POST'
HTTPS_DELETE = 'DELETE'


class EstimatorBase(with_metaclass(ABCMeta, object)):

    def __init__(self, modelarts_session, train_instance_count, train_instance_type,
                 output_path, base_job_name=None):

        self.modelarts_session = modelarts_session
        self.train_instance_count = train_instance_count
        self.train_instance_type = train_instance_type
        self.output_path = output_path
        self.base_job_name = base_job_name
        self._current_job_name = None
        self.access_key = modelarts_session.access_key
        self.secret_key = modelarts_session.secret_key
        self.host = modelarts_session.host
        self.client = modelarts_session.client
        self.project_id = modelarts_session.project_id

        self.model_api = Model(modelarts_session)

    def _prepare_for_training(self, job_name=None):
        if job_name is not None:
            self._current_job_name = job_name
        else:
            if self.base_job_name:
                base_name = self.base_job_name
            else:
                ISOTIMEFORMAT = '%m%d-%H%M%S'
                beijing_date = (datetime.now()+ timedelta(hours=8)).strftime(ISOTIMEFORMAT)
                base_name = 'job-' + beijing_date

            self._current_job_name = base_name
        return self._current_job_name

    def fit(self, inputs=None, wait=False, logs=None, job_name=None):
        """Train a model using the input training dataset.
        """

        job_name = self._prepare_for_training(job_name=job_name)

        if inputs is None:
            raise ValueError('Input data is needed for training')

        job_train_resp = _TrainingJob.start_new(self, inputs)
        if self.modelarts_session.auth == 'aksk':
            job_id = job_train_resp['job_id']
            version_id = job_train_resp['version_id']
        else:
            job_id = job_train_resp.job_id
            version_id = job_train_resp.version_id

        count_init = 0
        count_running = 0
        count_waiting = 0
        if wait:
            while True:
                resp, duration = self.get_job_state(job_id=job_id, version_id=version_id)
                if resp == 'JOBSTAT_COMPLETED':
                    print(resp)
                    seconds = duration / 1000
                    m, s = divmod(seconds, 60)
                    h, m = divmod(m, 60)
                    duration_format = "%02d:%02d:%02d" % (h, m, s)
                    print("Job [ %s ] duration is %s" % (job_name, duration_format))
                    break
                elif resp == 'JOBSTAT_INIT':
                    if count_init == 0:
                        print(resp)
                    count_init = count_init + 1
                    # self.print_job_middle_state(resp, count_init)
                    time.sleep(3)
                elif resp == 'JOBSTAT_WAITING':
                    if count_waiting == 0:
                        print(resp)
                    count_waiting = count_waiting + 1
                    # self.print_job_middle_state(resp, count_waiting)
                    time.sleep(5)
                elif resp == 'JOBSTAT_RUNNING':
                    if count_running == 0:
                        print(resp)
                    count_running = count_running + 1
                    # self.print_job_middle_state(resp, count_running)
                    time.sleep(8)
                else:
                    print("Job [ %s ] status is %s, please check log" % (job_name, resp))
                    break

        return str(job_id)

    def print_job_middle_state(self, state, count_init):
        count_init = count_init - 1
        print(state + '...' * count_init)

    def get_job_state(self, job_id, version_id):
        res = _TrainingJob.get_job_info(self, job_id, version_id)
        if self.modelarts_session.auth == 'aksk':
            status_id = res['status']
            status = JOB_STATE[status_id]
            duration = res['duration']
        else:
            status = JOB_STATE[res.status]
            duration = res.duration
        return status, duration

    @classmethod
    def get_spec_list(cls, modelarts_session):
        return _TrainingJob.get_spec_list(modelarts_session)

    @classmethod
    def get_train_instance_types(cls, modelarts_session):
        return _TrainingJob.get_train_instance_types(modelarts_session)

    @classmethod
    def get_engine_list(cls, modelarts_session):
        return _TrainingJob.get_engine_list(modelarts_session)

    @classmethod
    def get_framework_list(cls, modelarts_session):
        return _TrainingJob.get_framework_list(modelarts_session)

    def delete_job(self, job_id):
        return _TrainingJob.delete_job(self, job_id)

    def create_model(self, **kwargs):
        """ creating model interface
        :param kwargs: Create model body params
        :return: model instance
        """
        create_model_resp = self.model_api.create_model(**kwargs)
        return self.model_api

    def deploy_predictor(self, **kwargs):
        """Deploying model service interface
        :param kwargs:  Deploying predictor body params
        :return:  predictor
        """
        deploy_model_resp = self.model_api.deploy_predictor(**kwargs)
        return deploy_model_resp

    def deploy_transformer(self, **kwargs):
        """Deploying model service interface
        :param kwargs:  Deploying transformer body params
        :return:  transformer
        """
        deploy_model_resp = self.model_api.deploy_transformer(**kwargs)
        return deploy_model_resp

    def delete(self, job_id=None, model_id=None, service_id=None):

        _TrainingJob.delete_job(self, job_id)

        if model_id or service_id is not None:
            self.model_api.delete_model_endpoint(model_id=model_id, service_id=service_id)


class _TrainingJob():

    @classmethod
    def prepare_config(cls, estimator, inputs):

        _config = {}
        _config['worker_server_num'] = estimator.train_instance_count
        _config['app_url'] = estimator.code_dir
        _config['boot_file_url'] = estimator.boot_file
        _config['train_url'] = estimator.output_path
        _config['parameter'] = estimator.hyperparameters

        if estimator.model_name and (estimator.framework_version or estimator.framework_type):
            raise ValueError('model_name and framework_type is an either')

        if estimator.framework_version or estimator.framework_type:
            if estimator.framework_version and estimator.framework_type is None or estimator.framework_version is None and estimator.framework_type:
                raise ValueError('both framework_version and framework_type are needed')
            else:
                res = cls.get_engine_list(estimator.modelarts_session)
                if estimator.modelarts_session.auth == 'aksk':
                    engines = res['engines']
                    for engine in engines:
                        if engine['engine_name'] == estimator.framework_type and engine[
                            'engine_version'] == estimator.framework_version:
                            engine_id = engine['engine_id']
                            _config['engine_id'] = engine_id
                else:
                    engines = res.engines
                    for engine in engines:
                        engine = engine.to_dict()
                        if engine['engine_name'] == estimator.framework_type and engine[
                            'engine_version'] == estimator.framework_version:
                            engine_id = engine['engine_id']
                            _config['engine_id'] = engine_id

        if estimator.model_name:
            model_list = []
            model_id = ""
            res = cls.get_built_in_algorithms(estimator)
            if estimator.modelarts_session.auth == 'aksk':
                models = res['models']
                for model in models:
                    model_list.append(model['model_name'])
                    if model['model_name'] == estimator.model_name:
                        model_id = model['model_id']
                        break
            else:
                for model in res.models:
                    model = model.to_dict()
                    model_list.append(model['model_name'])
                    if model['model_name'] == estimator.model_name:
                        model_id = model['model_id']
                        break
            if estimator.model_name in model_list:
                _config['model_id'] = model_id
            else:
                raise ValueError('Invalid model_name')

        if estimator.train_instance_type:
            spec_list = []
            spec_id = ""
            res = cls.get_spec_list(estimator.modelarts_session)
            if estimator.modelarts_session.auth == 'aksk':
                specs = res['specs']
                for spec in specs:
                    spec_list.append(spec['spec_code'])
                    if spec['spec_code'] == estimator.train_instance_type:
                        spec_id = spec['spec_id']
            else:
                for spec in res.specs:
                    spec = spec.to_dict()
                    spec_list.append(spec['spec_code'])
                    if spec['spec_code'] == estimator.train_instance_type:
                        spec_id = spec['spec_id']

            if estimator.train_instance_type in spec_list:
                _config['spec_id'] = spec_id
            else:
                raise ValueError('Unrecognized ecs type of {}'.format(estimator.train_instance_type))

        if estimator.log_url:
            _config['log_url'] = estimator.log_url

        if estimator.user_image_url:
            _config['user_image_url'] = estimator.user_image_url

        if estimator.user_command:
            _config['user_command'] = estimator.user_command

        if isinstance(inputs, str):
            if inputs.startswith("/"):
                _config['data_url'] = inputs
            elif inputs.find(inputs, ",") != -1:
                dataset = inputs.split(",")
                dataset_name = dataset[0]
                dataset_list = []
                dataset_id = ""
                res = cls.get_datasets(estimator)
                if estimator.modelarts_session.auth == 'aksk':
                    datasets = res['datasets']
                    for dataset in datasets:
                        dataset_list.append(dataset['dataset_name'])
                        if dataset['dataset_name'] == dataset_name:
                            dataset_id = dataset['dataset_id']
                            break
                else:
                    for dataset in res.datasets:
                        dataset = dataset.to_dict()
                        dataset_list.append(dataset['dataset_name'])
                        if dataset['dataset_name'] == dataset_name:
                            dataset_id = dataset['dataset_id']
                            break
                _config['dataset_id'] = dataset_id

                version_list = []
                res = cls.get_datasets_versions_info(dataset_id=dataset_id)
                if estimator.modelarts_session.auth == 'aksk':
                    versions = res['versions']
                    ## TODO Check
                    for version in versions:
                        version_list.append(version['version_id'])
                else:
                    for version in res['versions']:
                        version_list.append(version['version_id'])
                if dataset[1] in version_list:
                    _config['dataset_version_id'] = dataset[1]
                else:
                    raise ValueError('Unrecognized version id of {}'.format(dataset[1]))

        elif isinstance(inputs, list):
            _config['data_source'] = inputs

        return _config

    @classmethod
    def start_new(cls, estimator, inputs):
        """Create a new training job from the estimator.
        """
        access_key = estimator.modelarts_session.access_key
        secret_key = estimator.modelarts_session.secret_key
        host = estimator.modelarts_session.host
        project_id = estimator.modelarts_session.project_id
        client = estimator.modelarts_session.client

        if estimator.job_description is None:
            estimator.job_description = ""

        _config = _TrainingJob.prepare_config(estimator, inputs)

        body = {
            "job_name": estimator._current_job_name,
            "job_desc": estimator.job_description,
            "config": _config
        }
        if estimator.modelarts_session.auth == 'aksk':
            request_url = '/v1/' + project_id + '/training-jobs'
            body = JSONEncoder().encode(body)
            res = auth_by_APIG(access_key, secret_key, HTTPS_POST, host, request_url, body=body)
        else:
            train_job_api = TrainJobApi(client)
            res = train_job_api.create_training_job(project_id=project_id, body=body)
        return res

    @classmethod
    def get_job_list(cls, estimator):
        if estimator.modelarts_session.auth == 'aksk':
            request_url = '/v1/' + estimator.project_id + '/training-jobs'
            res = auth_by_APIG(estimator.access_key, estimator.secret_key, HTTPS_GET, estimator.host, request_url)
        else:
            train_job_api = TrainJobApi(estimator.client)
            res = train_job_api.view_training_job(project_id=estimator.project_id)
        return res

    @classmethod
    def get_job_info(cls, estimator, job_id, version_id):
        if estimator.modelarts_session.auth == 'aksk':
            request_url = '/v1/' + estimator.project_id + '/training-jobs/' + str(job_id) + '/versions/' + str(version_id)
            res = auth_by_APIG(estimator.access_key, estimator.secret_key, HTTPS_GET, estimator.host, request_url)
        else:
            train_job_api = TrainJobApi(estimator.client)
            res = train_job_api.view_training_job(project_id=estimator.project_id, job_id=job_id, version_id=version_id)
        return res

    @classmethod
    def get_spec_list(cls, modelarts_session):
        if modelarts_session.auth == 'aksk':
            request_url = '/v1/' + modelarts_session.project_id + '/job/resource-specs'
            res = auth_by_APIG(modelarts_session.access_key, modelarts_session.secret_key, HTTPS_GET, modelarts_session.host, request_url)
        else:
            spec_api = SpecApi(modelarts_session.client)
            res = spec_api.list_spec(project_id=modelarts_session.modelarts_session.project_id)
        return res

    @classmethod
    def get_train_instance_types(cls, modelarts_session):
        res = cls.get_spec_list(modelarts_session)
        spec_list = []
        if modelarts_session.auth == 'aksk':
            specs = res['specs']
            for spec in specs:
                spec_list.append(spec['spec_code'])
        else:
            for spec in res.specs:
                spec = spec.to_dict()
                spec_list.append(spec['spec_code'])
        return spec_list

    @classmethod
    def get_engine_list(cls, modelarts_session):
        if modelarts_session.auth == 'aksk':
            request_url = '/v1/' + modelarts_session.project_id + '/job/ai-engines'
            res = auth_by_APIG(modelarts_session.access_key, modelarts_session.secret_key, HTTPS_GET, modelarts_session.host, request_url)
        else:
            engine_api = EngineApi(modelarts_session.client)
            res = engine_api.list_engine(project_id=modelarts_session.project_id)
        return res

    @classmethod
    def get_framework_list(cls, modelarts_session):
        res = cls.get_engine_list(modelarts_session)
        framework_list = []
        if modelarts_session.auth == 'aksk':
            engines = res['engines']
            for engine in engines:
                framework = {}
                framework['framework_type'] = engine['engine_name']
                framework['framework_version'] = engine['engine_version']
                framework_list.append(framework)
        else:
            engines = res.engines
            for engine in engines:
                engine = engine.to_dict()
                framework = {}
                framework['framework_type'] = engine['engine_name']
                framework['framework_version'] = engine['engine_version']
                framework_list.append(framework)
        return framework_list

    @classmethod
    def get_built_in_algorithms(cls, estimator):
        if estimator.modelarts_session.auth == 'aksk':
            request_url = '/v1/' + estimator.project_id + '/built-in-algorithms'
            res = auth_by_APIG(estimator.access_key, estimator.secret_key, HTTPS_GET, estimator.host, request_url)
        else:
            model_api = ModelApi(estimator.client)
            res = model_api.query_built_in_algorithms(estimator.project_id)
        return res

    @classmethod
    def get_datasets(cls, estimator):
        if estimator.modelarts_session.auth == 'aksk':
            request_url = '/v1/' + estimator.project_id + '/datasets'
            query = {"limit": "100"}
            res = auth_by_APIG(estimator.access_key, estimator.secret_key, HTTPS_GET, estimator.host, request_url, query=query)
        else:
            dataset_api = DatasetApi(self.client)
            res = dataset_api.query_dataset(project_id=estimator.project_id, limit=100)
        return res

    @classmethod
    def get_datasets_versions_info(cls, estimator, dataset_id):
        if estimator.modelarts_session.auth == 'aksk':
            request_url = '/v1/' + estimator.project_id + '/datasets/' + dataset_id + '/versions'
            res = auth_by_APIG(estimator.access_key, estimator.secret_key, HTTPS_GET, estimator.host, request_url)
        else:
            dataset_api = DatasetApi(estimator.client)
            res = dataset_api.get_history_dataset_version(project_id=estimator.project_id, dataset_id=dataset_id)
        return res

    @classmethod
    def delete_job(cls, estimator, job_id):
        if estimator.modelarts_session.auth == 'aksk':
            request_url = '/v1/' + estimator.project_id + '/training-jobs/' + str(job_id)
            auth_by_APIG(estimator.access_key, estimator.secret_key, HTTPS_DELETE, estimator.host, request_url)
        else:
            train_job_api = TrainJobApi(estimator.client)
            train_job_api.delete_training_job(project_id=estimator.project_id, job_id=str(job_id))
        count = 0
        while True:
            job_list = []
            if estimator.modelarts_session.auth == 'aksk':
                request_url = '/v1/' + estimator.project_id + '/training-jobs'
                query = {"per_page": "1000"}
                res = auth_by_APIG(estimator.access_key, estimator.secret_key, HTTPS_GET, estimator.host, request_url, query=query)
                jobs = res['jobs']
                for job in jobs:
                    job_list.append(job['job_id'])
            else:
                res = train_job_api.list_training_job(project_id=estimator.project_id, per_page=1000)
                for job in res.jobs:
                    job_list.append(job.job_id)
            if job_id in job_list:
                count = count + 1
                time.sleep(3)
            else:
                print('Successfully delete the job %s' % (job_id))
                break
            if count == 5:
                print('Job %s is not deleted after 15s, please check it from UI' % (job_id))
                break


class Estimator(EstimatorBase):

    def __init__(self, code_dir=None, boot_file=None, hyperparameters=None, framework_type=None,
                 framework_version=None, model_name=None, log_url=None, user_image_url=None, user_command=None,
                 job_description=None, **kwargs):

        self.code_dir = code_dir
        self.boot_file = boot_file
        self.hyperparameters = hyperparameters or []
        self.framework_type = framework_type
        self.framework_version = framework_version
        self.model_name = model_name
        self.log_url = log_url
        self.user_image_url = user_image_url
        self.user_command = user_command
        self.job_description = job_description

        super(Estimator, self).__init__(**kwargs)

    def check_param(self, params):
        if isinstance(params, list):
            pass

        param_dict = {}

        for param in params:
            if not param.has_key('param_name') or not param.has_key('param_type') or not param.has_key('url'):
                raise ValueError("param_name and param_type and url are needed")
            if param.has_key('min'):
                param_dict['min'] = param['min']
            if param.has_key('max'):
                param_dict['max'] = param['max']
            if param.has_key('param_desc'):
                param_dict['param_desc'] = param['param_desc']

            param_dict['param_name'] = param['param_name']
            param_dict['param_type'] = param['param_type']
            param_dict['url'] = param['url']